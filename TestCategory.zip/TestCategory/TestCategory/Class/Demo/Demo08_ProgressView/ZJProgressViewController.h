//
//  ZJProgressViewController.h
//  TestCategory
//
//  Created by ZJ on 1/16/17.
//  Copyright © 2017 ZJ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZJProgressViewController : UIViewController

@end
