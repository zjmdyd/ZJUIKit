//
//  ZJTestCollectionViewController.h
//  TestCategory
//
//  Created by ZJ on 12/17/16.
//  Copyright © 2016 ZJ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZJTestCollectionViewController : UITableViewController

@end
