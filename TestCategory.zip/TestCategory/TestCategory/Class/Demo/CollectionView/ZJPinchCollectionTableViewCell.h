//
//  ZJPinchCollectionTableViewCell.h
//  TestCategory
//
//  Created by ZJ on 12/28/16.
//  Copyright © 2016 ZJ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZJPinchCollectionTableViewCell : UITableViewCell

@property (nonatomic, strong) NSArray *objs;

@end
