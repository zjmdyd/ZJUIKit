//
//  ZJTestAlertViewController.h
//  TestCategory
//
//  Created by ZJ on 12/13/16.
//  Copyright © 2016 ZJ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZJTestAlertViewController : UIViewController

@end
