//
//  ViewController.m
//  TestCategory
//
//  Created by ZJ on 12/9/16.
//  Copyright © 2016 ZJ. All rights reserved.
//

#import "ViewController.h"

#import "ZJNSObjectCategory.h"
#import "ZJFondationCategory.h"
#import "ZJUIViewCategory.h"
#import "ZJControllerCategory.h"
#import "ZJViewHeaderFile.h"

@interface ViewController ()<UITableViewDataSource, UITableViewDelegate, ZJFooterViewDelegate> {
    NSArray *_vcNames;
}

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initAry];
    [self initSettiing];
}

- (void)initAry {
    _vcNames = @[@"ZJTestAlertViewController", @"ZJTestLabelViewController", @"ZJMentionViewController", @"ZJSystemViewController", @"ZJPickerViewController", @"ZJCollectionViewController", @"ZJCAReplicatorLayerViewController", @"ZJProgressViewController"];
}

- (void)initSettiing {
    self.navigationItem.title = @"ZJCustomTools";
    ZJFooterView  *foot = [ZJFooterView footerViewWithTitle:@"保存" delegate:self ];
    foot.tintColor = [UIColor whiteColor];
    foot.buttonBgColor = [UIColor redColor];
    
    self.tableView.tableFooterView = foot;
    [self.tableView registerCellWithSysIDs:@[SystemTableViewCell]];
    
    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc]
                                                 initWithTitle:@"" // 设置成功,xib与效果，但没效果why?
                                                 style:UIBarButtonItemStylePlain
                                                 target:self
                                                 action:nil];
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _vcNames.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:SystemTableViewCell];
    cell.textLabel.text = _vcNames[indexPath.row];
    
    return cell;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSString *name = @"ZJTestLabelViewController";//_vcNames[indexPath.row];
    UIViewController *vc = [self createVCWithName:name title:name];
    [self.navigationController pushViewController:vc animated:YES];
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    NSString *text = @"头视图";
    NSAttributedString *attText = [text attrWithFirstLineHeadIndent:16.0];
    
    return [UIView supplementViewWithAttributeText:attText supplementViewBgColor:[UIColor clearColor]];
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 40;
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    
    [self.tableView setNeedSeparatorMargin:NO];
    [self.tableView setNeedLayoutMargin:NO];
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}

#pragma mark - ZJFooterViewDelegate

- (void)footerViewDidClick:(ZJFooterView *)footView {

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

@end
