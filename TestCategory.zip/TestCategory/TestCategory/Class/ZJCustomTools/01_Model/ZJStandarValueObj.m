//
//  ZJStandarValueObj.m
//  SuperGymV4
//
//  Created by ZJ on 5/24/16.
//  Copyright © 2016 ZJ. All rights reserved.
//

#import "ZJStandarValueObj.h"

@implementation ZJStandarValueObj

@end
