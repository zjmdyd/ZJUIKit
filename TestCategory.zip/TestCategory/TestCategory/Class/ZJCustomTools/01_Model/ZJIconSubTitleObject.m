//
//  ZJIconSubTitleObject.m
//  DiabetesGuardForDoctor
//
//  Created by ZJ on 6/26/16.
//  Copyright © 2016 ZJ. All rights reserved.
//

#import "ZJIconSubTitleObject.h"

@implementation ZJIconSubTitleObject

@end
