//
//  ZJStandarValueObj.h
//  SuperGymV4
//
//  Created by ZJ on 5/24/16.
//  Copyright © 2016 ZJ. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZJStandarValueObj : NSObject

@property (nonatomic, strong) NSNumber *higherValue;
@property (nonatomic, strong) NSNumber *lowerValue; 

@end
