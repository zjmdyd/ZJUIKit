//
//  ZJHeaderFile.h
//  PhysicalDate
//
//  Created by ZJ on 3/19/16.
//  Copyright © 2016 ZJ. All rights reserved.
//

#ifndef ZJHeaderFile_h
#define ZJHeaderFile_h


#endif /* ZJHeaderFile_h */

#import "ZJCategoryHeaderFile.h"
#import "ZJModelHeaderFile.h"
#import "ZJViewHeaderFile.h"
#import "ZJControllerHeaderFile.h"
#import "ZJBLETool.h"

#define DefaultErrorMsg @"请求出错"
#define DefaultNetworkWarning @"网络已断开连接"
