//
//  ZJBLETool.h
//  Care
//
//  Created by ZJ on 8/8/16.
//  Copyright © 2016 ZJ. All rights reserved.
//

#ifndef ZJBLETool_h
#define ZJBLETool_h


#endif /* ZJBLETool_h */

#import "ZJBLEDeviceManager.h"
#import "ZJBLEDevice.h"