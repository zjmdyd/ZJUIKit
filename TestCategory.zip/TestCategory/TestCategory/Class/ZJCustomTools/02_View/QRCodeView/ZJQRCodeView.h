//
//  ZJQRCodeView.h
//  TestCategory
//
//  Created by ZJ on 1/2/17.
//  Copyright © 2017 ZJ. All rights reserved.
//

#ifndef ZJQRCodeView_h
#define ZJQRCodeView_h


#endif /* ZJQRCodeView_h */

#import "ZJQRView.h"
#import "ZJQRCodeViewController.h"
