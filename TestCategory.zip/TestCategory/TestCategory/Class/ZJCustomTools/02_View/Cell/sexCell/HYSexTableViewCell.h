//
//  HYSexTableViewCell.h
//  XAHealthDoctor
//
//  Created by ZJ on 1/9/17.
//  Copyright © 2017 ZJ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HYSexTableViewCell : UITableViewCell

@property (nonatomic, assign) NSInteger sexIndex;

@end
