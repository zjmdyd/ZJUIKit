//
//  HYPullDownSelectView.h
//  DiabetesGuardForDoctor
//
//  Created by ZJ on 6/28/16.
//  Copyright © 2016 ZJ. All rights reserved.
//

#import "ZJMaskView.h"

@interface HYPullDownSelectView : ZJMaskView

@property (nonatomic, copy) NSString *topTitle;
@property (nonatomic, strong) NSArray *titles;

@end
