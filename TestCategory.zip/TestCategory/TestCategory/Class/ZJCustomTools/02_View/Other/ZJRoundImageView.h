//
//  ZJRoundImageView.h
//  ButlerSugarDoctor
//
//  Created by ZJ on 4/6/16.
//  Copyright © 2016 csj. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 *  圆角imageView
 */
@interface ZJRoundImageView : UIImageView

@end
